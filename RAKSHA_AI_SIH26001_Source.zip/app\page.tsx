"use client";

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Activity, 
  Zap, 
  MapPin, 
  Layers, 
  Radio, 
  FileText, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  RefreshCw, 
  PhoneCall, 
  Users, 
  CloudRain, 
  Droplets, 
  Mountain, 
  Crosshair, 
  Info, 
  Clock, 
  ArrowUpRight,
  ShieldCheck,
  Navigation,
  Globe,
  UploadCloud,
  Check
} from 'lucide-react';
import { useDisasterData } from '@/hooks/useDisasterData';
import { LandslideZone, ResourceNode, calculateSpatialDistanceKm } from '@/lib/engine';

export default function Page() {
  const {
    zones,
    resources,
    logs,
    isOptimizing,
    isAutoStreamActive,
    executeOptimization,
    addCitizenReport,
    toggleAutoStream,
  } = useDisasterData();

  const [activeTab, setActiveTab] = useState<'command' | 'citizen'>('command');
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>('zone-tawang');
  const [mapLayer, setMapLayer] = useState<'bhuvan' | 'risk' | 'geology'>('bhuvan');
  const [logFilter, setLogFilter] = useState<string>('ALL');

  // Citizen Form State
  const [reportRegion, setReportRegion] = useState<string>('zone-tawang');
  const [fissureType, setFissureType] = useState<string>('Deep Structural Fissures');
  const [seepageLevel, setSeepageLevel] = useState<string>('Heavy Muddy Runoff');
  const [reporterName, setReporterName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);

  const selectedZone = zones.find(z => z.id === selectedZoneId) || zones[0];

  const handleCitizenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    addCitizenReport({
      zoneId: reportRegion,
      fissureType,
      seepageLevel,
      description,
      reporterName: reporterName || 'Anonymous Citizen Reporter',
    });

    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setDescription('');
      setReporterName('');
    }, 4000);
  };

  const filteredLogs = logFilter === 'ALL' 
    ? logs 
    : logs.filter(l => l.type === logFilter);

  // Statistics calculation
  const criticalCount = zones.filter(z => z.riskLevel === 'Critical').length;
  const moderateCount = zones.filter(z => z.riskLevel === 'Moderate').length;
  const safeCount = zones.filter(z => z.riskLevel === 'Safe').length;
  const dispatchedResources = resources.filter(r => r.status === 'Dispatched').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans bg-tech-grid">
      
      {/* ========================================================================= */}
      {/* HEADER NAVBAR */}
      {/* ========================================================================= */}
      <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur-md sticky top-0 z-50 px-4 lg:px-8 py-3">
        <div className="max-w-[1800px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo & Meta Tags */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-950/50">
                <ShieldAlert className="h-6 w-6 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-bold text-xl tracking-wider text-white flex items-center gap-2">
                    RAKSHA<span className="text-cyan-400 font-extrabold">-AI</span>
                  </h1>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-700/50">
                    SIH PS 26001
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-medium">
                  Landslide Early Warning & Risk Monitoring System • North-Eastern Region (NER)
                </p>
              </div>
            </div>

            {/* Heartbeat Status Indicator */}
            <div className="flex items-center gap-2 md:hidden">
              <button 
                onClick={toggleAutoStream}
                className="flex items-center gap-1.5 text-xs bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-full text-slate-300"
              >
                <span className={`h-2 w-2 rounded-full ${isAutoStreamActive ? 'bg-emerald-500 animate-ping' : 'bg-amber-500'}`} />
                {isAutoStreamActive ? 'LIVE 4s' : 'PAUSED'}
              </button>
            </div>
          </div>

          {/* Center Meta & Active Heartbeat Status (Desktop) */}
          <div className="hidden lg:flex items-center gap-6 text-xs text-slate-400 font-mono">
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
              <Globe className="h-4 w-4 text-cyan-400" />
              <span>ISRO Bhuvan Sync: <strong className="text-emerald-400 font-normal">Active</strong></span>
            </div>

            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
              <Activity className="h-4 w-4 text-amber-400" />
              <span>Telemetry Loop:</span>
              <button 
                onClick={toggleAutoStream}
                className="flex items-center gap-1.5 hover:text-white transition-colors"
                title="Click to toggle streaming loop"
              >
                <span className={`h-2.5 w-2.5 rounded-full ${isAutoStreamActive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                <span className="text-slate-200">{isAutoStreamActive ? 'PULSING (4s Sync)' : 'PAUSED'}</span>
              </button>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-rose-400 font-bold bg-rose-950/60 border border-rose-900 px-2 py-0.5 rounded">
                {criticalCount} Critical
              </span>
              <span className="text-amber-400 font-bold bg-amber-950/60 border border-amber-900 px-2 py-0.5 rounded">
                {moderateCount} Moderate
              </span>
              <span className="text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-900 px-2 py-0.5 rounded">
                {safeCount} Safe
              </span>
            </div>
          </div>

          {/* Primary Action Button */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={executeOptimization}
              disabled={isOptimizing}
              className={`w-full md:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all duration-300 shadow-lg ${
                isOptimizing 
                  ? 'bg-cyan-950 border border-cyan-600 text-cyan-300 cursor-wait' 
                  : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white border border-cyan-400/30 shadow-cyan-900/40 hover:shadow-cyan-600/30'
              }`}
            >
              <Zap className={`h-4 w-4 ${isOptimizing ? 'animate-spin text-cyan-400' : 'text-yellow-300'}`} />
              <span>{isOptimizing ? 'Evaluating Spatial Proximity Matrix...' : 'Execute Optimization Engine'}</span>
            </button>
          </div>

        </div>
      </header>

      {/* ========================================================================= */}
      {/* NAVIGATION TAB CONTROLLER */}
      {/* ========================================================================= */}
      <div className="border-b border-slate-800 bg-slate-900/60 px-4 lg:px-8 py-2">
        <div className="max-w-[1800px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('command')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-xs md:text-sm transition-all ${
                activeTab === 'command'
                  ? 'bg-cyan-950/90 text-cyan-300 border border-cyan-700/60 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Radio className="h-4 w-4" />
              <span>Command Center Matrix</span>
            </button>

            <button
              onClick={() => setActiveTab('citizen')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-xs md:text-sm transition-all ${
                activeTab === 'citizen'
                  ? 'bg-cyan-950/90 text-cyan-300 border border-cyan-700/60 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <FileText className="h-4 w-4" />
              <span>Citizen Field Reporter</span>
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
            </button>
          </div>

          <div className="text-xs text-slate-400 hidden sm:flex items-center gap-2 font-mono">
            <span>NER Coordinate Grid: <strong className="text-slate-200 font-normal">23.4°N - 27.6°N | 88.6°E - 94.1°E</strong></span>
          </div>
        </div>
      </div>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-[1800px] w-full mx-auto p-4 lg:p-6 flex flex-col gap-6">

        {/* ========================================================================= */}
        {/* VIEWPORT 1: COMMAND CENTER MATRIX */}
        {/* ========================================================================= */}
        {activeTab === 'command' && (
          <div className="flex flex-col gap-6">

            {/* TOP GRID MATRIX: LEFT PANEL (TELEMETRY) | CENTER PANEL (MAP) | RIGHT PANEL (FLEET) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* ----------------------------------------------------------------- */}
              {/* LEFT PANEL: TELEMETRY SECTOR CARDS */}
              {/* ----------------------------------------------------------------- */}
              <div className="lg:col-span-3 flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h2 className="text-sm font-bold tracking-wide uppercase text-slate-300 flex items-center gap-2">
                    <Activity className="h-4 w-4 text-cyan-400" />
                    Telemetry Sectors ({zones.length})
                  </h2>
                  <span className="text-xs text-slate-500 font-mono">Sensors Live</span>
                </div>

                <div className="flex flex-col gap-3 max-h-[640px] overflow-y-auto pr-1">
                  {zones.map(zone => {
                    const isSelected = zone.id === selectedZoneId;

                    let colorTheme = {
                      badge: 'bg-emerald-950/80 text-emerald-400 border-emerald-800',
                      bar: 'bg-emerald-500',
                      text: 'text-emerald-400',
                      border: 'hover:border-emerald-500/40',
                      glow: 'shadow-emerald-950/30'
                    };
                    if (zone.riskLevel === 'Moderate') {
                      colorTheme = {
                        badge: 'bg-amber-950/80 text-amber-400 border-amber-800',
                        bar: 'bg-amber-500',
                        text: 'text-amber-400',
                        border: 'hover:border-amber-500/40',
                        glow: 'shadow-amber-950/30'
                      };
                    } else if (zone.riskLevel === 'Critical') {
                      colorTheme = {
                        badge: 'bg-rose-950/80 text-rose-400 border-rose-800 animate-pulse',
                        bar: 'bg-rose-500',
                        text: 'text-rose-400',
                        border: 'border-rose-500/60 shadow-rose-950/40',
                        glow: 'shadow-rose-950/50'
                      };
                    }

                    return (
                      <div
                        key={zone.id}
                        onClick={() => setSelectedZoneId(zone.id)}
                        className={`cursor-pointer bg-slate-900/90 border rounded-xl p-4 transition-all duration-200 relative overflow-hidden ${
                          isSelected 
                            ? `border-cyan-500 ring-1 ring-cyan-500/50 shadow-lg ${colorTheme.glow}` 
                            : `border-slate-800/80 ${colorTheme.border}`
                        }`}
                      >
                        {/* Header */}
                        <div className="flex items-start justify-between gap-2 mb-3">
                          <div>
                            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                              <MapPin className={`h-3.5 w-3.5 ${colorTheme.text}`} />
                              {zone.name}
                            </h3>
                            <p className="text-xs text-slate-400">{zone.state} • {zone.elevation}m</p>
                          </div>
                          <span className={`text-[11px] font-bold uppercase px-2 py-0.5 rounded border ${colorTheme.badge}`}>
                            {zone.riskLevel} ({zone.riskScore}%)
                          </span>
                        </div>

                        {/* Progress Bar for Risk Score */}
                        <div className="mb-3">
                          <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
                            <span>Computed Risk Index</span>
                            <span className={`font-bold ${colorTheme.text}`}>{zone.riskScore}%</span>
                          </div>
                          <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
                            <div 
                              className={`h-full rounded-full transition-all duration-500 ${colorTheme.bar}`}
                              style={{ width: `${zone.riskScore}%` }}
                            />
                          </div>
                        </div>

                        {/* Sensor Breakdown Indicators */}
                        <div className="grid grid-cols-3 gap-2 text-[11px] font-mono bg-slate-950/70 p-2 rounded-lg border border-slate-800/60">
                          <div className="flex flex-col">
                            <span className="text-slate-500 flex items-center gap-1">
                              <CloudRain className="h-3 w-3 text-cyan-400" /> Rain
                            </span>
                            <span className="font-bold text-slate-200">{zone.rainfall} <span className="text-[9px] text-slate-400">mm/h</span></span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-slate-500 flex items-center gap-1">
                              <Droplets className="h-3 w-3 text-blue-400" /> Soil
                            </span>
                            <span className="font-bold text-slate-200">{zone.soilMoisture}%</span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-slate-500 flex items-center gap-1">
                              <Mountain className="h-3 w-3 text-amber-400" /> Slope
                            </span>
                            <span className="font-bold text-slate-200">{zone.slopeAngle}°</span>
                          </div>
                        </div>

                        {/* Assigned Battalion Node */}
                        {zone.assignedResource && (
                          <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-cyan-400">
                            <span className="flex items-center gap-1 text-[11px]">
                              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" /> Bound: {zone.assignedResource.name}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">Dispatched</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* ----------------------------------------------------------------- */}
              {/* CENTER PANEL: INTERACTIVE GEOSPATIAL MAP MODULE */}
              {/* ----------------------------------------------------------------- */}
              <div className="lg:col-span-6 flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Layers className="h-4 w-4 text-cyan-400" />
                    <h2 className="text-sm font-bold tracking-wide uppercase text-slate-300">
                      Geospatial Risk Vector Matrix
                    </h2>
                  </div>

                  {/* Map Layer Mode Switcher */}
                  <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-lg text-xs">
                    <button
                      onClick={() => setMapLayer('bhuvan')}
                      className={`px-2.5 py-1 rounded font-medium transition-colors ${
                        mapLayer === 'bhuvan' 
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      ISRO Bhuvan
                    </button>
                    <button
                      onClick={() => setMapLayer('risk')}
                      className={`px-2.5 py-1 rounded font-medium transition-colors ${
                        mapLayer === 'risk' 
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Heat Risk
                    </button>
                    <button
                      onClick={() => setMapLayer('geology')}
                      className={`px-2.5 py-1 rounded font-medium transition-colors ${
                        mapLayer === 'geology' 
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Fault Lines
                    </button>
                  </div>
                </div>

                {/* Map Display Frame */}
                <div className="relative bg-slate-900/90 border border-slate-800 rounded-2xl h-[560px] overflow-hidden flex flex-col justify-between shadow-2xl">
                  
                  {/* Top Bar Overlay */}
                  <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
                    <div className="bg-slate-950/80 backdrop-blur border border-slate-800 px-3 py-1.5 rounded-lg text-xs font-mono text-cyan-400 pointer-events-auto flex items-center gap-2">
                      <Crosshair className="h-4 w-4 animate-spin text-cyan-400" />
                      <span>Grid: North-Eastern Region (NER)</span>
                    </div>

                    <div className="bg-slate-950/80 backdrop-blur border border-slate-800 px-3 py-1.5 rounded-lg text-xs text-slate-300 pointer-events-auto flex items-center gap-3">
                      <span className="flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full bg-rose-500 animate-ping" /> Critical Zone
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full bg-amber-500" /> Moderate
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /> NDRF Base
                      </span>
                    </div>
                  </div>

                  {/* Geospatial Interactive Canvas (SVG Vector Map Simulation for NER) */}
                  <div className="relative w-full h-full bg-[#050913] flex items-center justify-center overflow-hidden">
                    
                    {/* Simulated Radar Grid lines */}
                    <div className="absolute inset-0 bg-tech-grid opacity-30" />
                    <div className="absolute h-96 w-96 rounded-full border border-cyan-500/10 animate-pulse pointer-events-none" />
                    <div className="absolute h-[600px] w-[600px] rounded-full border border-cyan-500/5 pointer-events-none" />

                    {/* Vector Lines Connecting Critical/Moderate Zones to NDRF/SDRF Battalions */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none">
                      {zones.map(z => {
                        if (!z.assignedResource) return null;
                        
                        // Map coordinates to SVG percentage slots
                        // Lat: 23-28 -> Y (top to bottom), Lng: 88-95 -> X (left to right)
                        const zX = ((z.lng - 88.0) / (95.0 - 88.0)) * 100;
                        const zY = 100 - ((z.lat - 23.0) / (28.5 - 23.0)) * 100;

                        const rX = ((z.assignedResource.lng - 88.0) / (95.0 - 88.0)) * 100;
                        const rY = 100 - ((z.assignedResource.lat - 23.0) / (28.5 - 23.0)) * 100;

                        return (
                          <g key={`vector-${z.id}`}>
                            <line 
                              x1={`${zX}%`} 
                              y1={`${zY}%`} 
                              x2={`${rX}%`} 
                              y2={`${rY}%`} 
                              stroke="#06b6d4" 
                              strokeWidth="2" 
                              strokeDasharray="4,4" 
                              className="animate-pulse" 
                            />
                            <circle cx={`${zX}%`} cy={`${zY}%`} r="4" fill="#06b6d4" />
                          </g>
                        );
                      })}
                    </svg>

                    {/* Render Landslide Zone Nodes on Map */}
                    {zones.map(z => {
                      const isSelected = z.id === selectedZoneId;
                      // Mapping coordinates to visual positions on NER canvas
                      const posX = ((z.lng - 88.0) / (95.0 - 88.0)) * 100;
                      const posY = 100 - ((z.lat - 23.0) / (28.5 - 23.0)) * 100;

                      let nodeColor = 'bg-emerald-500 border-emerald-300 text-emerald-400';
                      let pingColor = 'bg-emerald-500';
                      if (z.riskLevel === 'Moderate') {
                        nodeColor = 'bg-amber-500 border-amber-300 text-amber-400';
                        pingColor = 'bg-amber-500';
                      } else if (z.riskLevel === 'Critical') {
                        nodeColor = 'bg-rose-500 border-rose-300 text-rose-400';
                        pingColor = 'bg-rose-500';
                      }

                      return (
                        <div
                          key={`map-zone-${z.id}`}
                          onClick={() => setSelectedZoneId(z.id)}
                          style={{ left: `${posX}%`, top: `${posY}%` }}
                          className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20 group"
                        >
                          {/* Pulsing ring */}
                          <div className={`absolute -inset-3 rounded-full opacity-40 animate-ping ${pingColor}`} />
                          
                          {/* Marker Dot */}
                          <div className={`relative h-7 w-7 rounded-full border-2 flex items-center justify-center shadow-lg transition-transform duration-300 group-hover:scale-125 ${
                            isSelected ? 'scale-125 ring-4 ring-cyan-400/50' : ''
                          } ${nodeColor.split(' ')[0]} border-white`}>
                            <MapPin className="h-4 w-4 text-slate-950 font-bold" />
                          </div>

                          {/* Hover Tooltip */}
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:flex flex-col bg-slate-950/95 border border-slate-700 p-2.5 rounded-lg shadow-xl text-xs whitespace-nowrap z-30">
                            <span className="font-bold text-slate-100">{z.name}</span>
                            <span className="text-[10px] text-slate-400">{z.state}</span>
                            <span className={`font-mono font-bold mt-1 ${nodeColor.split(' ')[2]}`}>
                              Risk Index: {z.riskScore}% ({z.riskLevel})
                            </span>
                          </div>
                        </div>
                      );
                    })}

                    {/* Render Responder Node Base Markers */}
                    {resources.map(r => {
                      const posX = ((r.lng - 88.0) / (95.0 - 88.0)) * 100;
                      const posY = 100 - ((r.lat - 23.0) / (28.5 - 23.0)) * 100;

                      return (
                        <div
                          key={`map-res-${r.id}`}
                          style={{ left: `${posX}%`, top: `${posY}%` }}
                          className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10 group"
                          title={`${r.name} (${r.status})`}
                        >
                          <div className="h-5 w-5 bg-cyan-950 border border-cyan-400 rounded-md flex items-center justify-center text-cyan-300 shadow-md">
                            <ShieldCheck className="h-3 w-3" />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Bottom Map Details Footer Card */}
                  <div className="bg-slate-950/95 border-t border-slate-800 p-4 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-cyan-950 border border-cyan-700/50 flex items-center justify-center text-cyan-400">
                        <Navigation className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="font-bold text-slate-200">
                          Selected Sector: {selectedZone.name} ({selectedZone.state})
                        </div>
                        <div className="text-slate-400 font-mono text-[11px]">
                          Lat: {selectedZone.lat}°N | Lng: {selectedZone.lng}°E | Saturation: {selectedZone.soilMoisture}%
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 font-mono">Bound Battalion:</span>
                      {selectedZone.assignedResource ? (
                        <span className="px-2.5 py-1 bg-cyan-950 border border-cyan-700/60 rounded text-cyan-300 font-medium">
                          {selectedZone.assignedResource.name} ({selectedZone.assignedResource.type})
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-500">
                          Unassigned
                        </span>
                      )}
                    </div>
                  </div>

                </div>
              </div>

              {/* ----------------------------------------------------------------- */}
              {/* RIGHT PANEL: RESPONSE FLEET REGISTRY */}
              {/* ----------------------------------------------------------------- */}
              <div className="lg:col-span-3 flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h2 className="text-sm font-bold tracking-wide uppercase text-slate-300 flex items-center gap-2">
                    <Users className="h-4 w-4 text-cyan-400" />
                    Response Fleet ({dispatchedResources}/{resources.length} Active)
                  </h2>
                  <span className="text-xs text-slate-500 font-mono">NDRF / SDRF</span>
                </div>

                <div className="flex flex-col gap-3 max-h-[640px] overflow-y-auto pr-1">
                  {resources.map(res => {
                    const isDispatched = res.status === 'Dispatched';
                    const boundZone = zones.find(z => z.id === res.assignedZoneId);

                    return (
                      <div
                        key={res.id}
                        className={`bg-slate-900/90 border rounded-xl p-4 transition-all duration-200 ${
                          isDispatched 
                            ? 'border-cyan-500/70 bg-cyan-950/20 shadow-md shadow-cyan-950/30' 
                            : 'border-slate-800/80 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div>
                            <span className="text-[10px] font-bold font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 text-cyan-400 border border-slate-700">
                              {res.type}
                            </span>
                            <h3 className="font-bold text-sm text-slate-200 mt-1">
                              {res.name}
                            </h3>
                            <p className="text-xs text-slate-400">{res.baseCity}</p>
                          </div>

                          <span className={`text-[11px] font-bold uppercase px-2 py-0.5 rounded border ${
                            isDispatched
                              ? 'bg-amber-950 text-amber-400 border-amber-800 animate-pulse'
                              : 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          }`}>
                            {res.status}
                          </span>
                        </div>

                        <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs font-mono text-slate-400">
                          <span className="flex items-center gap-1">
                            <Users className="h-3.5 w-3.5 text-slate-500" /> {res.capacity} Personnel
                          </span>
                          <span className="flex items-center gap-1 text-slate-300">
                            <PhoneCall className="h-3 w-3 text-cyan-400" /> {res.contact}
                          </span>
                        </div>

                        {/* Bound Zone Info if Dispatched */}
                        {isDispatched && boundZone && (
                          <div className="mt-2.5 p-2 rounded bg-slate-950 border border-cyan-800/50 text-[11px] flex items-center justify-between text-cyan-300">
                            <span>Target: <strong>{boundZone.name}</strong></span>
                            <span className="font-mono text-emerald-400">
                              {calculateSpatialDistanceKm(res.lat, res.lng, boundZone.lat, boundZone.lng)} km
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* ========================================================================= */}
            {/* BOTTOM STREAM: OPERATIONAL LOGGING TICKER WINDOW */}
            {/* ========================================================================= */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 shadow-xl">
              
              {/* Header Controls */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-cyan-400 animate-pulse" />
                  <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200">
                    Operational Log Ticker Stream
                  </h2>
                  <span className="text-xs text-slate-500 font-mono">({filteredLogs.length} Events)</span>
                </div>

                {/* Log Level Filters */}
                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto text-xs">
                  {['ALL', 'INFO', 'WARNING', 'ALERT', 'OPTIMIZE', 'CITIZEN_REPORT'].map(type => (
                    <button
                      key={type}
                      onClick={() => setLogFilter(type)}
                      className={`px-2.5 py-1 rounded font-mono font-medium transition-colors whitespace-nowrap ${
                        logFilter === type 
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/60' 
                          : 'text-slate-400 hover:text-white bg-slate-950/60'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Log Ticker Scroll Window */}
              <div className="bg-slate-950 rounded-xl border border-slate-800/80 p-3 h-48 overflow-y-auto font-mono text-xs flex flex-col gap-2">
                {filteredLogs.length === 0 ? (
                  <div className="text-slate-600 italic text-center py-6">No logs for selected filter.</div>
                ) : (
                  filteredLogs.map(log => {
                    let badgeStyle = 'bg-slate-800 text-slate-300 border-slate-700';
                    if (log.type === 'ALERT') badgeStyle = 'bg-rose-950 text-rose-400 border-rose-800 font-bold';
                    if (log.type === 'WARNING') badgeStyle = 'bg-amber-950 text-amber-400 border-amber-800';
                    if (log.type === 'OPTIMIZE') badgeStyle = 'bg-cyan-950 text-cyan-300 border-cyan-700 font-bold';
                    if (log.type === 'CITIZEN_REPORT') badgeStyle = 'bg-purple-950 text-purple-300 border-purple-800 font-bold';

                    return (
                      <div 
                        key={log.id} 
                        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 p-2 rounded bg-slate-900/50 border border-slate-800/40 hover:bg-slate-900 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 flex-1 flex-wrap">
                          <span className="text-slate-500 text-[11px] min-w-[70px]">{log.timestamp}</span>
                          <span className={`px-2 py-0.5 text-[10px] rounded border ${badgeStyle}`}>
                            {log.type}
                          </span>
                          <span className="text-slate-200 font-semibold">{log.message}</span>
                        </div>

                        {log.details && (
                          <span className="text-[11px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800/60 max-w-md truncate">
                            {log.details}
                          </span>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEWPORT 2: CITIZEN FIELD REPORTER PORTAL */}
        {/* ========================================================================= */}
        {activeTab === 'citizen' && (
          <div className="max-w-4xl mx-auto w-full flex flex-col gap-6">
            
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 border border-cyan-800/50 rounded-2xl p-6 shadow-xl">
              <div className="flex items-start gap-4">
                <div className="h-12 w-12 rounded-xl bg-cyan-950 border border-cyan-500 flex items-center justify-center text-cyan-400 shrink-0">
                  <FileText className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    Citizen Incident & Ground Fissure Reporting Portal
                  </h2>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Direct early warning channel for residents, regional engineers, and local authorities across the North-Eastern Region. Submitting a field report immediately updates the RAKSHA-AI Landslide Risk Engine and alerts disaster response teams.
                  </p>
                </div>
              </div>
            </div>

            {/* Submission Form Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl">
              
              {formSubmitted ? (
                <div className="py-12 flex flex-col items-center justify-center text-center gap-4">
                  <div className="h-16 w-16 rounded-full bg-emerald-950 border border-emerald-500 flex items-center justify-center text-emerald-400 animate-bounce">
                    <Check className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-bold text-white">Incident Report Dispatched Successfully!</h3>
                  <p className="text-sm text-slate-400 max-w-md">
                    Your field data has been ingested into the live RAKSHA-AI telemetry loop. The local soil saturation metrics have been updated and nearest NDRF/SDRF response units alerted.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleCitizenSubmit} className="flex flex-col gap-6">
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Region Selection */}
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                        <MapPin className="h-3.5 w-3.5 text-cyan-400" />
                        Target Region / Sector *
                      </label>
                      <select
                        value={reportRegion}
                        onChange={(e) => setReportRegion(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        {zones.map(z => (
                          <option key={z.id} value={z.id}>
                            {z.name} ({z.state})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Crack / Fissure Classification */}
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                        Crack / Fissure Classification *
                      </label>
                      <select
                        value={fissureType}
                        onChange={(e) => setFissureType(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        <option value="Hairline Surface Cracks">Hairline Surface Cracks (Minor)</option>
                        <option value="Deep Structural Fissures">Deep Structural Fissures (Severe)</option>
                        <option value="Active Mudslide Flow">Active Mudslide Flow (Immediate Danger)</option>
                        <option value="Rockfall Hazard & Road Blockade">Rockfall Hazard & Road Blockade</option>
                      </select>
                    </div>

                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Seepage Level */}
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                        <Droplets className="h-3.5 w-3.5 text-blue-400" />
                        Water Seepage Intensity *
                      </label>
                      <select
                        value={seepageLevel}
                        onChange={(e) => setSeepageLevel(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        <option value="Dry Ground">Dry Ground / No Visible Water</option>
                        <option value="Minor Damp Seepage">Minor Damp Seepage</option>
                        <option value="Heavy Muddy Runoff">Heavy Muddy Runoff / Gushing Water</option>
                      </select>
                    </div>

                    {/* Reporter Name / Contact */}
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5 text-slate-400" />
                        Reporter Name / Contact (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., Tashi Dorjee (+91 98765-43210)"
                        value={reporterName}
                        onChange={(e) => setReporterName(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                      />
                    </div>

                  </div>

                  {/* Incident Description */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                      <FileText className="h-3.5 w-3.5 text-slate-400" />
                      Detailed Incident Observation & Landmark *
                    </label>
                    <textarea
                      rows={4}
                      required
                      placeholder="Describe slope displacement, affected roadways, nearby village clusters, or visible soil movement..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>

                  {/* Photo Attachment Placeholder Dropzone */}
                  <div className="border-2 border-dashed border-slate-800 rounded-xl p-6 bg-slate-950/50 flex flex-col items-center justify-center text-center gap-2 hover:border-cyan-500/50 transition-colors cursor-pointer">
                    <UploadCloud className="h-8 w-8 text-cyan-400" />
                    <span className="text-xs font-bold text-slate-300">Attach Field Evidence / Geotagged Photo</span>
                    <span className="text-[11px] text-slate-500">Supports JPG, PNG, WEBP (Mock Image Preview Active)</span>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="flex items-center justify-center gap-2 w-full py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-950/50 transition-all border border-cyan-400/30"
                  >
                    <Send className="h-4 w-4" />
                    <span>Submit Incident Report to RAKSHA-AI Matrix</span>
                  </button>

                </form>
              )}

            </div>

          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-800/80 bg-slate-950 px-4 lg:px-8 py-4 mt-auto text-xs text-slate-500 flex flex-col md:flex-row items-center justify-between gap-3 font-mono">
        <div>
          RAKSHA-AI • Early Warning & Landslide Risk Monitoring System in NER (SIH Problem Statement 26001)
        </div>
        <div className="flex items-center gap-4">
          <span>ISRO Bhuvan GIS Layer</span>
          <span>•</span>
          <span>NDRF & SDRF Coordination Matrix</span>
          <span>•</span>
          <span className="text-cyan-400 font-bold">Antigravity Engine Active</span>
        </div>
      </footer>

    </div>
  );
}
