# RAKSHA-AI | AI-Based Landslide Early Warning & Risk Monitoring System in NER
> **Smart India Hackathon (SIH) Problem Statement 26001**  
> *Developed for Ministry of Development of North Eastern Region (MDoNER) / ISRO Bhuvan GIS Integration*

---

## 🌟 Overview
**RAKSHA-AI** is a high-fidelity early warning and disaster response optimization platform tailored for landslide-prone zones in the North-Eastern Region (NER) of India (*Arunachal Pradesh, Meghalaya, Sikkim, Assam, Nagaland*).

The platform continuously evaluates multi-spectral telemetry parameters, calculates dynamic landslide risk indexes (0-100%), and optimizes responder fleet allocation (NDRF & SDRF battalions) using spatial proximity binding matrix algorithms.

---

## 🚀 Key Features

1. **Algorithmic Landslide Risk Evaluation Engine**
   - Weighted formula: **Precipitation (50%) + Soil Moisture Saturation (30%) + Slope Gradient (20%)**
   - Qualitative Alert Classification:
     - 🟢 **Safe** (< 40%)
     - 🟠 **Moderate** (40% - 70%)
     - 🔴 **Critical** (> 70%)

2. **Geospatial Proximity Matrix (`Math.hypot`)**
   - Coordinates emergency responder nodes (NDRF/SDRF) to critical landslide zones based on minimal spatial Euclidean distance.

3. **Live Telemetry Simulator & Log Ticker**
   - 4-second streaming sync clock simulating localized rainfall anomalies and soil absorption gains.
   - Real-time terminal log ticker with filter controls (`INFO`, `WARNING`, `ALERT`, `OPTIMIZE`, `CITIZEN_REPORT`).

4. **Interactive Command Center & ISRO Bhuvan Overlay**
   - Vector geospatial canvas featuring ISRO Bhuvan satellite styling, topographically pulsed alert markers, and responder binding vectors.

5. **Citizen Field Reporter Portal**
   - Direct ground-truth incident reporting form with region selection, crack fissure classification, water seepage levels, and photo evidence upload placeholder.

---

## 🛠️ Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript (Strict enforcement)
- **Styling**: Tailwind CSS (Dark slate technical theme)
- **Icons**: Lucide React
- **Deployment**: Vercel / Netlify / Cloudflare Pages / Custom Node Server

---

## 💻 Local Development Setup

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run Development Server**:
   ```bash
   npm run dev
   ```

3. Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🌐 One-Click Public Deployment (Vercel / Netlify)

### Option A: Deploy to Vercel (Recommended)
1. Push this code repository to GitHub / GitLab / Bitbucket.
2. Go to [Vercel](https://vercel.com) and click **"Add New Project"**.
3. Import your repository. Vercel will automatically detect Next.js settings.
4. Click **"Deploy"**. Your app will be live on a public `.vercel.app` domain in 60 seconds!

### Option B: Deploy to Netlify
1. Log into [Netlify](https://netlify.com).
2. Import project from Git.
3. Build command: `npm run build` | Output directory: `.next`
4. Click **"Deploy"**.

---

## 🗺️ Monitored NER Geographical Sectors

| Sector | State | Coordinates | Geology |
| :--- | :--- | :--- | :--- |
| **Tawang Sector 4** | Arunachal Pradesh | 27.586° N, 91.859° E | Weathered Gneiss & Loose Granite |
| **Cherrapunji Plateau** | Meghalaya | 25.298° N, 91.733° E | Saturated Limestone & Karst |
| **Gangtok East Ridge** | Sikkim | 27.338° N, 88.606° E | Disintegrated Mica Schists |
| **Haflong Hill Cut** | Assam | 25.170° N, 93.016° E | Unconsolidated Clay & Sand |
| **Kohima Bypass Pass** | Nagaland | 25.675° N, 94.108° E | Fractured Disintegrated Shale |
