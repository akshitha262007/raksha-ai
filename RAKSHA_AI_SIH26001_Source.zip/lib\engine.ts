/**
 * RAKSHA-AI Core Risk Evaluation & Resource Allocation Engine
 * Smart India Hackathon Problem Statement 26001: Landslide Risk Monitoring System in NER
 */

export interface ResourceNode {
  id: string;
  name: string;
  type: 'NDRF' | 'SDRF' | 'Civil Defence';
  lat: number;
  lng: number;
  status: 'Available' | 'Dispatched';
  capacity: number;
  contact: string;
  assignedZoneId?: string | null;
  baseCity: string;
}

export interface LandslideZone {
  id: string;
  name: string;
  state: string;
  lat: number;
  lng: number;
  rainfall: number; // Precipitation intensity in mm/hr (0 - 120 mm/hr)
  soilMoisture: number; // Soil volumetric water content % (0 - 100%)
  slopeAngle: number; // Terrain gradient in degrees (0 - 75°)
  riskScore: number; // Evaluated risk score percentage (0 - 100%)
  riskLevel: 'Safe' | 'Moderate' | 'Critical';
  assignedResource: ResourceNode | null;
  lastUpdated: string;
  elevation: number; // Meters above sea level
  geologicalComposition: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'INFO' | 'WARNING' | 'ALERT' | 'OPTIMIZE' | 'CITIZEN_REPORT';
  message: string;
  zoneId?: string;
  details?: string;
}

/**
 * Algorithmic evaluation of Landslide Risk Score (0-100%)
 * Formula Weights:
 * - Rain (Precipitation): 50%
 * - Soil Moisture: 30%
 * - Slope Gradient: 20%
 */
export function calculateLandslideRisk(rain: number, moisture: number, slope: number): number {
  // Normalize Rain: 0 to 100 mm/hr scales to 0-100%
  const normalizedRain = Math.min(100, Math.max(0, (rain / 100) * 100));
  
  // Soil moisture is directly 0-100%
  const normalizedMoisture = Math.min(100, Math.max(0, moisture));
  
  // Normalize Slope: 0° to 60° scales to 0-100% (60°+ is extreme gradient)
  const normalizedSlope = Math.min(100, Math.max(0, (slope / 60) * 100));

  // Weighted calculation (50% Rain, 30% Moisture, 20% Slope)
  const weightedScore = (normalizedRain * 0.50) + (normalizedMoisture * 0.30) + (normalizedSlope * 0.20);

  // Return clamped & rounded value (0-100)
  return Math.round(Math.min(100, Math.max(0, weightedScore)) * 10) / 10;
}

/**
 * Utility to determine qualitative risk classification from score
 */
export function getRiskLevel(score: number): 'Safe' | 'Moderate' | 'Critical' {
  if (score >= 70) return 'Critical';
  if (score >= 40) return 'Moderate';
  return 'Safe';
}

/**
 * Coordinate Proximity Matrix for Disaster Fleet Binding
 * Uses Euclidean hypot distance tracking on lat/lng coordinates to find closest available responder battalion node.
 */
export function matchZoneToClosestResource(zone: LandslideZone, resources: ResourceNode[]): ResourceNode | null {
  // Prefer available resources first
  const availableResources = resources.filter(r => r.status === 'Available');
  const candidatePool = availableResources.length > 0 ? availableResources : resources;

  if (candidatePool.length === 0) return null;

  let closestResource: ResourceNode | null = null;
  let minDistance = Infinity;

  for (const resource of candidatePool) {
    // Mathematical hypot distance evaluation
    const distance = Math.hypot(zone.lat - resource.lat, zone.lng - resource.lng);
    if (distance < minDistance) {
      minDistance = distance;
      closestResource = resource;
    }
  }

  return closestResource;
}

/**
 * Helper to calculate spatial distance in km (Haversine formula) for display UI
 */
export function calculateSpatialDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}
