import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RAKSHA-AI | Early Warning & Landslide Risk Monitoring System in NER',
  description: 'AI-Based early warning and landslide Risk Monitoring System in North Eastern Region (NER) - Smart India Hackathon PS 26001',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 min-h-screen selection:bg-cyan-500 selection:text-black">
        {children}
      </body>
    </html>
  );
}
