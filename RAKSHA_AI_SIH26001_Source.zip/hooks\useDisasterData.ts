"use client";

import { useState, useEffect, useCallback } from 'react';
import { 
  LandslideZone, 
  ResourceNode, 
  LogEntry, 
  calculateLandslideRisk, 
  getRiskLevel, 
  matchZoneToClosestResource,
  calculateSpatialDistanceKm
} from '@/lib/engine';

const INITIAL_ZONES: LandslideZone[] = [
  {
    id: 'zone-tawang',
    name: 'Tawang Sector 4',
    state: 'Arunachal Pradesh',
    lat: 27.586,
    lng: 91.859,
    rainfall: 78, // mm/hr
    soilMoisture: 82, // %
    slopeAngle: 52, // degrees
    riskScore: 78.4,
    riskLevel: 'Critical',
    assignedResource: null,
    lastUpdated: new Date().toLocaleTimeString(),
    elevation: 3048,
    geologicalComposition: 'Weathered Gneiss & Loose Granite',
  },
  {
    id: 'zone-cherrapunji',
    name: 'Cherrapunji Plateau',
    state: 'Meghalaya',
    lat: 25.298,
    lng: 91.733,
    rainfall: 92, // mm/hr
    soilMoisture: 88, // %
    slopeAngle: 44, // degrees
    riskScore: 87.1,
    riskLevel: 'Critical',
    assignedResource: null,
    lastUpdated: new Date().toLocaleTimeString(),
    elevation: 1484,
    geologicalComposition: 'Saturated Sandstone & Karst Limestone',
  },
  {
    id: 'zone-gangtok',
    name: 'Gangtok East Ridge',
    state: 'Sikkim',
    lat: 27.338,
    lng: 88.606,
    rainfall: 38, // mm/hr
    soilMoisture: 54, // %
    slopeAngle: 38, // degrees
    riskScore: 47.9,
    riskLevel: 'Moderate',
    assignedResource: null,
    lastUpdated: new Date().toLocaleTimeString(),
    elevation: 1650,
    geologicalComposition: 'Phyllites & Disintegrated Mica Schists',
  },
  {
    id: 'zone-haflong',
    name: 'Haflong Hill Cut',
    state: 'Assam',
    lat: 25.170,
    lng: 93.016,
    rainfall: 22, // mm/hr
    soilMoisture: 42, // %
    slopeAngle: 28, // degrees
    riskScore: 32.9,
    riskLevel: 'Safe',
    assignedResource: null,
    lastUpdated: new Date().toLocaleTimeString(),
    elevation: 680,
    geologicalComposition: 'Tertiary Clay & Unconsolidated Sand',
  },
  {
    id: 'zone-kohima',
    name: 'Kohima Bypass Pass',
    state: 'Nagaland',
    lat: 25.675,
    lng: 94.108,
    rainfall: 64, // mm/hr
    soilMoisture: 72, // %
    slopeAngle: 48, // degrees
    riskScore: 69.6,
    riskLevel: 'Moderate',
    assignedResource: null,
    lastUpdated: new Date().toLocaleTimeString(),
    elevation: 1444,
    geologicalComposition: 'Fractured Disintegrated Shale',
  }
];

const INITIAL_RESOURCES: ResourceNode[] = [
  {
    id: 'res-ndrf-12',
    name: '12th Battalion NDRF',
    type: 'NDRF',
    lat: 27.100,
    lng: 93.620,
    baseCity: 'Itanagar, Arunachal Pradesh',
    status: 'Available',
    capacity: 120,
    contact: '+91 360-228-4921',
  },
  {
    id: 'res-sdrf-1',
    name: '1st Battalion SDRF',
    type: 'SDRF',
    lat: 25.578,
    lng: 91.893,
    baseCity: 'Shillong, Meghalaya',
    status: 'Available',
    capacity: 85,
    contact: '+91 364-250-1122',
  },
  {
    id: 'res-ndrf-qrt-sikkim',
    name: 'NDRF Rapid Response Base',
    type: 'NDRF',
    lat: 27.330,
    lng: 88.610,
    baseCity: 'Gangtok, Sikkim',
    status: 'Available',
    capacity: 60,
    contact: '+91 3592-202-774',
  },
  {
    id: 'res-ndrf-10',
    name: '10th Battalion NDRF HQ',
    type: 'NDRF',
    lat: 26.144,
    lng: 91.736,
    baseCity: 'Guwahati, Assam',
    status: 'Available',
    capacity: 160,
    contact: '+91 361-284-0199',
  },
  {
    id: 'res-civil-kohima',
    name: 'Nagaland Disaster Taskforce',
    type: 'Civil Defence',
    lat: 25.670,
    lng: 94.100,
    baseCity: 'Kohima, Nagaland',
    status: 'Available',
    capacity: 75,
    contact: '+91 370-229-0050',
  }
];

export function useDisasterData() {
  const [zones, setZones] = useState<LandslideZone[]>(INITIAL_ZONES);
  const [resources, setResources] = useState<ResourceNode[]>(INITIAL_RESOURCES);
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 'log-1',
      timestamp: new Date().toLocaleTimeString(),
      type: 'INFO',
      message: 'RAKSHA-AI Risk Engine initialized. Connected to ISRO Bhuvan NER Telemetry Feed.',
      details: 'Active Monitoring: Tawang, Cherrapunji, Gangtok, Haflong, Kohima'
    },
    {
      id: 'log-2',
      timestamp: new Date().toLocaleTimeString(),
      type: 'WARNING',
      message: 'High precipitation anomaly detected in Meghalaya & Arunachal Sectors.',
      details: 'Rainfall intensity > 75 mm/hr. Soil saturation index critical.'
    }
  ]);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [isAutoStreamActive, setIsAutoStreamActive] = useState<boolean>(true);

  // Helper to add log entries
  const addLog = useCallback((type: LogEntry['type'], message: string, details?: string, zoneId?: string) => {
    const newEntry: LogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toLocaleTimeString(),
      type,
      message,
      details,
      zoneId
    };
    setLogs(prev => [newEntry, ...prev.slice(0, 49)]); // Keep last 50 logs
  }, []);

  // Continuous 4-second sensor telemetry clock loop
  useEffect(() => {
    if (!isAutoStreamActive) return;

    const interval = setInterval(() => {
      setZones(prevZones => {
        return prevZones.map(zone => {
          // Simulate realistic precipitation fluctuations (-6 to +8 mm/hr)
          const rainDelta = (Math.random() * 14 - 6);
          const newRain = Math.min(115, Math.max(5, Math.round(zone.rainfall + rainDelta)));

          // Simulate soil moisture absorption / drainage (-2% to +3%)
          const moistureDelta = (Math.random() * 5 - 2);
          const newMoisture = Math.min(98, Math.max(15, Math.round(zone.soilMoisture + moistureDelta)));

          // Calculate updated landslide risk score
          const newScore = calculateLandslideRisk(newRain, newMoisture, zone.slopeAngle);
          const newRiskLevel = getRiskLevel(newScore);

          // Alert on critical threshold crossing
          if (newRiskLevel === 'Critical' && zone.riskLevel !== 'Critical') {
            addLog(
              'ALERT', 
              `CRITICAL RISK ELEVATION: ${zone.name} (${zone.state}) score reached ${newScore}%!`,
              `Rain: ${newRain}mm/hr | Soil Saturation: ${newMoisture}% | Slope: ${zone.slopeAngle}°`,
              zone.id
            );
          }

          return {
            ...zone,
            rainfall: newRain,
            soilMoisture: newMoisture,
            riskScore: newScore,
            riskLevel: newRiskLevel,
            lastUpdated: new Date().toLocaleTimeString(),
          };
        });
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [isAutoStreamActive, addLog]);

  // Execute Optimization Engine
  const executeOptimization = useCallback(() => {
    setIsOptimizing(true);
    addLog('OPTIMIZE', 'Executing Optimization Engine: Spatial Proximity & Fleet Allocation...');

    setTimeout(() => {
      setZones(prevZones => {
        let updatedResources = [...resources];

        const updatedZones = prevZones.map(zone => {
          // Calculate recalculated risk score to ensure fresh evaluation
          const freshScore = calculateLandslideRisk(zone.rainfall, zone.soilMoisture, zone.slopeAngle);
          const freshLevel = getRiskLevel(freshScore);

          if (freshLevel === 'Critical' || freshLevel === 'Moderate') {
            const matchedRes = matchZoneToClosestResource(zone, updatedResources);

            if (matchedRes) {
              const distanceKm = calculateSpatialDistanceKm(zone.lat, zone.lng, matchedRes.lat, matchedRes.lng);
              
              // Update resource status in array
              updatedResources = updatedResources.map(r => 
                r.id === matchedRes.id 
                  ? { ...r, status: 'Dispatched', assignedZoneId: zone.id } 
                  : r
              );

              const assignedResourceUpdated: ResourceNode = {
                ...matchedRes,
                status: 'Dispatched',
                assignedZoneId: zone.id
              };

              addLog(
                'OPTIMIZE',
                `OPTIMIZER MATCH: Bound ${matchedRes.name} -> ${zone.name} (${distanceKm} km hypot distance).`,
                `Fleet Node: ${matchedRes.baseCity} | Capacity: ${matchedRes.capacity} Personnel | Zone Risk: ${freshScore}%`,
                zone.id
              );

              return {
                ...zone,
                riskScore: freshScore,
                riskLevel: freshLevel,
                assignedResource: assignedResourceUpdated,
              };
            }
          }
          return {
            ...zone,
            riskScore: freshScore,
            riskLevel: freshLevel,
          };
        });

        setResources(updatedResources);
        return updatedZones;
      });

      setIsOptimizing(false);
      addLog('INFO', 'Optimization Engine Run Complete. Disaster Response Matrix fully aligned.');
    }, 800);
  }, [resources, addLog]);

  // Citizen incident reporting event handler
  const addCitizenReport = useCallback((report: {
    zoneId: string;
    fissureType: string;
    seepageLevel: string;
    description: string;
    reporterName?: string;
    contact?: string;
  }) => {
    const targetZone = zones.find(z => z.id === report.zoneId);
    const locationName = targetZone ? `${targetZone.name} (${targetZone.state})` : report.zoneId;

    // Immediately elevate target zone soil moisture & recalculate risk
    setZones(prev => prev.map(zone => {
      if (zone.id === report.zoneId) {
        const elevatedMoisture = Math.min(99, zone.soilMoisture + 12);
        const elevatedRain = Math.min(110, zone.rainfall + 10);
        const newScore = calculateLandslideRisk(elevatedRain, elevatedMoisture, zone.slopeAngle);
        const newLevel = getRiskLevel(newScore);

        return {
          ...zone,
          soilMoisture: elevatedMoisture,
          rainfall: elevatedRain,
          riskScore: newScore,
          riskLevel: newLevel,
          lastUpdated: new Date().toLocaleTimeString(),
        };
      }
      return zone;
    }));

    addLog(
      'CITIZEN_REPORT',
      `CITIZEN FIELD INCIDENT FILED: ${locationName}`,
      `Fissure Classification: ${report.fissureType} | Seepage: ${report.seepageLevel} | Details: "${report.description}"`,
      report.zoneId
    );
  }, [zones, addLog]);

  // Toggle stream status
  const toggleAutoStream = useCallback(() => {
    setIsAutoStreamActive(prev => !prev);
    addLog('INFO', `Sensor telemetry clock loop ${!isAutoStreamActive ? 'RESUMED' : 'PAUSED'}.`);
  }, [isAutoStreamActive, addLog]);

  return {
    zones,
    resources,
    logs,
    isOptimizing,
    isAutoStreamActive,
    executeOptimization,
    addCitizenReport,
    toggleAutoStream,
    addLog,
  };
}
